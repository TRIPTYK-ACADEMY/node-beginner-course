## La terre est plate ?
- **Vrai**
- Faux